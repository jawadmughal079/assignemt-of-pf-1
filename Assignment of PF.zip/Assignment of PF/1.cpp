#include <iostream>
#include <string>
using namespace std;
void sizeGet();
void whatIsProgramme();
void inputNames(int size, string *names);
void outputNames(int size, string *names);
void sortingProcess(int size, string *names);
void swapTheNames(string &name1, string &name2);
int main()
{

    whatIsProgramme();
    cout << endl;
    int size = 0;
    sizeGet();
    cout << "\nAMOUNT :  ";
    cin >> size;

    cout << endl;
    string *names = new string[size];
    cout << "\n----------------------NOW START THE ENTER NAMES INTO PROGRAM ---------------------------------\n";
    inputNames(size, names);
    cout << "\n----------------------NAMES ARE SHOW YOU INPUT INTO PROGRAM---------------------------------\n";
    outputNames(size, names);
    cout << endl;
    cout << "\n----------------------NAMES AFTER SWAPING---------------------------------\n";
    sortingProcess(size, names);
    outputNames(size, names);

    return 0;
}

void inputNames(int size, string *names)
{
    for (int i = 0; i < size; i++)
    {
        cout << " Enter a ";
        cout << "#" << i + 1;
        cout << " Name ";

        cin >> names[i];
    }
}
void outputNames(int size, string *names)
{
    for (int i = 0; i < size; i++)
    {
        cout << "# " << i + 1 << " names ";

        cout << names[i] << "    \n ";
    }
}
void sortingProcess(int size, string *names)
{
    int counter = 1;
    while (counter < size)
    {
        for (int i = 0; i < size - counter; i++)
        {
            if (names[i] > names[i + 1])
            {
                swapTheNames(names[i], names[i + 1]);
            }
        }

        counter++;
    }
}
void swapTheNames(string &name1, string &name2)
{
    string temp = name1;
    name1 = name2;
    name2 = temp;
}
void whatIsProgramme()
{
    cout << "\n----------------------PRINT THE SORTED LIST OF NAMES---------------------------------\n";
}
void sizeGet()
{
    cout << " \nHow many names would you like to enter? \n";
}