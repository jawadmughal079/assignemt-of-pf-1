#include <iostream>
using namespace std;
void sizeGet();
void whatIsProgramme();
void inputNames(int size, int *arr);
void outputNames(int size, int *names);
void unionArray(int size3, int size1, int size2, int *arr1, int *arr2, int *arr3);
void intersectionArray(int size3, int size1, int size2, int *arr1, int *arr2, int *arr4);
void inputGet();
void outputGet();
int total1 = 0;
int total2 = 0;
int main()
{

    int size1 = 0;
    int size2 = 0;
    sizeGet();
    cin >> size1;
    sizeGet();
    cin >> size2;
    int *arr1 = new int[size1];
    int *arr2 = new int[size2];
    int *arr3 = nullptr;
    int *arr4 = nullptr;
    int size3 = size1 + size2;
    arr3 = new int[size3];
    arr4 = new int[size3];
    inputGet();
    inputNames(size1, arr1);
    inputGet();
    inputNames(size2, arr2);
    outputGet();
    outputNames(size1, arr1);
    outputGet();
    outputNames(size2, arr2);

    cout << "\n VALUE AFTER UNION \n";
    unionArray(size3, size1, size2, arr1, arr2, arr3);
    cout << endl;
    outputNames(total1, arr3);
    cout << "\n VALUE AFTER INTERSECTION \n";
    intersectionArray(size3, size1, size2, arr1, arr2, arr4);
    cout << endl;
    outputNames(total2, arr4);

    return 0;
}
void sizeGet()
{
    cout << "\nHow many size would you like to enter? \n";
}
void inputGet()
{
    cout << "\nENTER THE NUMBERS PLEASE \n ";
}
void outputGet()
{
    cout << "\nYOUR INPUT NUMBERS  \n ";
}
void inputNames(int size, int *arr)
{
    for (int i = 0; i < size; i++)
    {
        cout << " Enter a ";
        cout << " #" << i + 1;
        cout << " NUM :";

        cin >> arr[i];
    }
}
void outputNames(int size, int *arr)
{
    for (int i = 0; i < size; i++)
    {
        cout << " # " << i + 1 << " NUM :";

        cout << arr[i] << "    \n ";
    }
}
void whatIsProgramme()
{
    cout << "\n----------------------PRINT THE UNION AND INTERSECTION OF ARRAY---------------------------------\n";
}
void unionArray(int size3, int size1, int size2, int *arr1, int *arr2, int *arr3)
{
    int l = 0;
    for (int i = 0; i < size3; i++)
    {
        if (i < size1)
        {
            arr3[i] = arr1[i];
        }
        else
        {
            arr3[i] = arr2[l++];
        }
    }
    for (int i = 0; i < size3; i++)
    {
        int j = 0;
        for (j = 0; j < i; j++)
        {
            if (arr3[i] == arr3[j])
            {
                break;
            }
        }
        if (i == j)
        {
            arr3[total1++] = arr3[i];
        }
    }
}
void intersectionArray(int size3, int size1, int size2, int *arr1, int *arr2, int *arr4)
{

    int l = 0;
    int counter = 0;
    int j = 0;

    for (int i = 0; i < size3; i++)
    {
        if (i < size1)
        {
            arr4[i] = arr1[i];
        }
        else
        {
            arr4[i] = arr2[l++];
        }
    }

    for (int i = 0; i < size3; i++)
    {

        for (j = i + 1; j < size3; j++)
        {
            if (arr4[i] == arr4[j])
            {
                arr4[total2++] = arr4[i];
                break;
            }
        }
    }
}